package com.ffd.api.admin.service;

public interface AdminLoginService {

    String login(String email, String password) throws Exception;

}
