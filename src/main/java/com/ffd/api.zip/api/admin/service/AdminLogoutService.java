package com.ffd.api.admin.service;

public interface AdminLogoutService {

    void logout(String token);

}
